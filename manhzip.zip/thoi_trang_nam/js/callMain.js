var config = undefined;
var ua = undefined;
var session = undefined;
var options = undefined;
var client = undefined;
var ringbacktone = document.getElementById("ringbacktone");
const SESSION_STATUS = {
  IDLE: 9,
  OUTBOUND_STARTING: 1,
  OUTBOUND_RINGING: 2,
  INBOUND_RINGING: 4,
  ANSWERING: 12,
};
const on_number_phone = $("#on-phone-number").attr("data-toggle");
const domain = $("#domain").val();
if (on_number_phone == "false") {
  $(".call .number").addClass("hidden");
  $("#output").addClass("hidden");
  $(".text-cskh").removeClass("hidden");
} else {
  $(".call .number").removeClass("hidden");
  $(".call #output").removeClass("hidden");
  $(".text-cskh").addClass("hidden");
}

$(".bg-call").click(function () {
  $(".call-box").removeClass("hidden");
  $(".bg-call").addClass("hidden");
  $(".bg-call .fa.fa-phone").addClass("open");
});
$(".call-box-exit").click(function () {
  $(".call-box").addClass("hidden");
  $(".bg-call").removeClass("hidden");
  $(".bg-call .fa.fa-phone").removeClass("open");
});
$(".digit").click(function () {
  var input_phone = $(".input-phone-number").val();
  var digit = $(this).attr("data");
  $(".input-phone-number").val(input_phone + digit);
});
$(".remove-number").click(function () {
  var str = $(".input-phone-number").val();
  $(".input-phone-number").val(str.substring(0, str.length - 1));
});
$(".remove-number").click(function () {
  var str = $(".input-phone-number").val();
  $(".input-phone-number").val(str.substring(0, str.length - 1));
});
$("#button-call").click(function () {
  var phone = $(".input-phone-number").val();
  if (checkPhoneNumber(phone)) {
    $(".calling-wrap").removeClass("hidden");
    $(".call").addClass("hidden");
    if (on_number_phone == "false") {
      $(".info-call.info-call-transfer .phone-number").text("Đang gọi ...");
    } else {
      $(".info-call.info-call-transfer .phone-number").text(phone);
    }
    handleButtonCallClick();
  } else {
  }
});
$(".custom-btn.btn-called").click(function () {
  $(".calling-wrap").addClass("hidden");
  $(".call").removeClass("hidden");
});

$("#register").click(function () {
  if (domain.length > 0) {
    var api =
      "https://api-dev-rnd.cmctelecom.vn/api/v2/subscription-service/subcriber/api-connect/get-extensions-guest-free";
    var method = "POST";
    var data = { domain: domain };
    callApi(api, method, data)
      .then((res) => {
        var url = res.result.data.item.endpoint;
        var arr = url.split(":");
        var username = res.result.data.item.userId;
        var password = res.result.data.item.password;
        var hostname = arr[1].replace("//", "");
        var port = arr[2];
        handlePageLoad(username, password, hostname, port);
        $("#status").removeClass("danger").addClass("success");
        $("#status").text("Đăng ký thành công");
        if (on_number_phone == "false") {
          var api =
            "https://api-dev-rnd.cmctelecom.vn/api/v2/subscription-service/subcriber/api-connect/get-target";
          var method = "POST";
          callApi(api, method, data)
            .then((res) => {
              let target = res.result.data.item.target;
              $(".input-phone-number").val(target);
            })
            .catch((error) => {
              $("#button-call").text("Đang kết nối ...");
              $("#button-call").removeClass("color-5").addClass("color-danger");
              console.log(error);
            });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }
});
function handlePageLoad(username, password, hostname, port) {
  var path = "";
  config = {
    displayName: username,
    uri: `sip:${username}@${hostname}`,
    transportOptions: { wsServers: [`wss://${hostname}:${port}${path}`] },
    authorizationUsersip: username,
    password: password,
    sessionDescriptionHandlerOptions: {
      constraints: {
        audio: true,
        video: false,
      },
    },
  };
  ua = new SIP.UA(config);
  ua.on("connected", function () {
    console.log("conected  (Unregistered)");
    $("#button-call").text("Đang kết nối ...");
    $("#button-call").removeClass("color-5").addClass("color-danger");
    $("#button-call").attr("disabled", true);
  });
  ua.on("registered", function () {
    $("#button-call").text("Gọi");
    $("#button-call").removeClass("color-danger").addClass("color-5");
    $("#button-call").attr("disabled", false);
    console.log("registered");
  });

  ua.on("unregistered", function () {
    console.log("unregistered");
    $("#button-call").text("Hệ thống bận ...");
    $("#button-call").removeClass("color-5").addClass("color-danger");
    $("#button-call").attr("disabled", true);
  });
  ua.on("error", function (error) {
    console.log("ERROR", error);
  });
  ua.on("invite", function (s) {
    session = s;
    session.type = "inbound";
    showRingingCallElements();

    session.on("accepted", function () {
      console.log("ACCEPTED");
      showAnswerCallElements();
    });
    session.on("rejected", function () {
      console.log("REJECTED");
      showIdleCallElements();
    });
    session.on("cancel", function () {
      console.log("CANCEL");
      showIdleCallElements();
    });
    session.on("failed", function () {
      console.log("FAILED");
      showIdleCallElements();
    });
    session.on("bye", function () {
      console.log("BYE");
      showIdleCallElements();
    });
    session.on("trackAdded", function () {
      console.log("TRACK_ADDED");
      var pc = session.sessionDescriptionHandler.peerConnection;
      var player = document.getElementById("player");
      var remoteStream = new MediaStream();
      pc.getReceivers().forEach(function (receiver) {
        remoteStream.addTrack(receiver.track);
      });
      if (typeof player.srcObject !== "undefined") {
        player.srcObject = remoteStream;
      } else if (typeof player.mozSrcObject !== "undefined") {
        player.mozSrcObject = remoteStream;
      } else if (typeof player.src !== "undefined") {
        player.src = URL.createObjectURL(remoteStream);
      } else {
        console.log("Error attaching stream to element.");
      }
      player.play();
    });
  });
}

function handleButtonCallClick() {
  let status = SESSION_STATUS.IDLE;
  let input_phone = document.getElementById("input-phone").value;
  console.log("session", session);
  if (session) {
    status = session.status;
  }
  if (status === SESSION_STATUS.IDLE) {
    session = ua.invite(input_phone, {
      media: {
        constraints: {
          audio: true,
          video: false,
        },
      },
      sessionDescriptionHandlerOptions: {
        constraints: {
          audio: true,
          video: false,
        },
      },
    });
    session.type = "outbound";
    session.on("progress", function (response) {
      if (
        response.statusCode == 183 &&
        response.body &&
        session.hasOffer &&
        !session.dialog
      ) {
        if (
          !response.hasHeader("require") ||
          response.getHeader("require").indexOf("100rel") === -1
        ) {
          if (
            session.sessionDescriptionHandler.hasDescription(
              response.getHeader("Content-Type")
            )
          ) {
            // @hack: https://github.com/onsip/SIP.js/issues/242
            session.status = SIP.Session.C.STATUS_EARLY_MEDIA;
            waitingForApplyingAnswer(response);
          }
        }
      }
    });
    showAnswerCallElements();

    session.on("accepted", function () {
      console.log("ACCEPTED");
      showAnswerCallElements();
    });
    session.on("rejected", function (s) {
      console.log("REJECTED");
      showIdleCallElements();
    });
    session.on("cancel", function () {
      console.log("CANCEL");
      showIdleCallElements();
    });
    session.on("failed", function (req) {
      switch (req.reasonPhrase) {
        case "Busy Here":
          return console.log("Máy bận");
        case "Not Found":
          return console.log("số không tồn tại");
        default:
          break;
      }
      console.log("FAILED");
      showIdleCallElements();
    });
    session.on("bye", function () {
      console.log("BYE");
      showIdleCallElements();
    });

    session.on("unavailable", function () {
      console.log("UNAVAILABLE");
    });

    session.on("not found", function () {
      console.log("NOT_FOUND");
    });
    session.on("trackAdded", function () {
      console.log("TRACK_ADDED 2");
      document.getElementById("call-duration").innerHTML = secondsTimeSpanToHMS(
        Math.floor((new Date() - session.startTime) / 1000)
      );
      $(".calling-state").removeClass("hidden");
      var pc = session.sessionDescriptionHandler.peerConnection;
      var player = document.getElementById("player");
      var remoteStream = new MediaStream();

      pc.getReceivers().forEach(function (receiver) {
        remoteStream.addTrack(receiver.track);
      });

      if (typeof player.srcObject !== "undefined") {
        player.srcObject = remoteStream;
      } else if (typeof player.mozSrcObject !== "undefined") {
        player.mozSrcObject = remoteStream;
      } else if (typeof player.src !== "undefined") {
        player.src = URL.createObjectURL(remoteStream);
      } else {
        console.log("Error attaching stream to element.");
      }
      player.play();
    });
  }
}

function showIdleCallElements(callType) {
  $(".calling-state").addClass("hidden");
  $(".calling-wrap").addClass("hidden");
  $(".call").removeClass("hidden");
}

function showAnswerCallElements(callType) {
  // document.getElementById('button-answer').style.display = "none";
  // document.getElementById('button-hangup').style.display = "inline";
  // document.getElementById('button-transfer').style.display = "inline";
  // document.getElementById('input-phone-transfer').style.display = "inline";
  // document.getElementById('button-call').style.display = "none";
  // document.getElementById('input-phone').style.display = "none";
}

function checkPhoneNumber(phone) {
  if (phone.length > 0) {
    return true;
  } else {
    return false;
  }
}
var updateCallInfoInterval = setInterval(function () {
  if (session) {
    // console.log(session)
    // document.getElementById("session-status").innerHTML = session.status;
    switch (session.status) {
      case SESSION_STATUS.IDLE: {
        document.getElementById("call-duration").innerHTML = "";
        break;
      }
      case SESSION_STATUS.ANSWERING: {
        document.getElementById("call-duration").innerHTML =
          secondsTimeSpanToHMS(
            Math.floor((new Date() - session.startTime) / 1000)
          );
        $(".calling-state").removeClass("hidden");
        break;
      }
      case SESSION_STATUS.INBOUND_RINGING:
      case SESSION_STATUS.OUTBOUND_RINGING: {
        break;
      }
      default:
        break;
    }
  }
}, 500);

function showRingingCallElements(callType) {}

function handleButtonAnswerClick() {
  let option = {
    sessionDescriptionHandlerOptions: {
      constraints: {
        audio: true,
        video: false,
      },
    },
  };
  session.accept(option);
}
function handleButtonHangupClick() {
  session.terminate();
}
function handleButtonTransferClick() {
  if (session.status === SESSION_STATUS.ANSWERING) {
    //nó đang không hiểu biến UserAgent.makeURI này. nên không register được
    var _session = ua.invite(
      `${document.getElementById("input-phone-transfer").value}@${
        document.getElementById("input-hostname").value
      }`,
      {
        media: {
          constraints: {
            audio: true,
            video: false,
          },
        },
        sessionDescriptionHandlerOptions: {
          constraints: {
            audio: true,
            video: false,
          },
        },
        // inviteWithoutSdp: true,
        // rel100: SIP.C.supported.SUPPORTED,
        activeAfterTransfer: false, //die when the transfer is completed
      }
    );
    // const replacementSession = newInviter('22707', UserAgent.makeURI(`sip:${document.getElementById("input-phone-transfer").value}@${document.getElementById("input-hostname").value}`);
    session.refer(_session);
    // session.refer(`sip:${document.getElementById("input-phone-transfer").value}@${document.getElementById("input-hostname").value}`);
  }
}

function startRingbackTone() {
  console.log("playyyyyyy", ringbacktone);
  try {
    ringbacktone.play();
    ringbacktone[0].play();
  } catch (e) {}
}

function stopRingbackTone() {
  try {
    ringbacktone.pause();
  } catch (e) {}
}

function waitingForApplyingAnswer(response) {
  let i = 1,
    clearTimer;

  setTimeout(function check() {
    i++;
    clearTimer = setTimeout(check, 10);
    if (session.hasAnswer || i > 14) {
      if (session.hasAnswer) {
        clearTimeout(clearTimer);
      } else if (i === 15) {
        clearTimeout(clearTimer);
        session.sessionDescriptionHandler
          .setDescription(response.body)
          .catch((error) => {
            session.logger.warn(error);
            session.failed(response, C.causes.BAD_MEDIA_DESCRIPTION);
            session.terminate({
              statusCode: 488,
              reason_phrase: "Bad Media Description",
            });
          });
      }
    }
  }, 10);
}

function secondsTimeSpanToHMS(s) {
  var h = Math.floor(s / 3600); //Get whole hours
  s -= h * 3600;
  var m = Math.floor(s / 60); //Get remaining minutes
  s -= m * 60;
  return h + ":" + (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s); //zero padding on minutes and seconds
}

function callApi(api, method, data) {
  return new Promise((resolve, reject) => {
    $.ajax({
      url: api,
      type: method,
      dataType: "json",
      data: JSON.stringify(data),
      contentType: "application/json",
      success: function (res) {
        resolve(res);
      },
      error: function (xhr, textStatus, errorThrown) {
        console.log("Error in Operation");
        reject(false);
        return false;
      },
    });
  });
}
